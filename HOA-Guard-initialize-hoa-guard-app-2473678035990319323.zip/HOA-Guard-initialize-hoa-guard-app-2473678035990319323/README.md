# HOA Guard

## AI-Powered Homeowner Protection & Fine Prevention App

HOA Guard is an innovative AI-powered solution designed to help homeowners navigate the complexities of Homeowners Association (HOA) rules and regulations.

### Key Features
- **AI Rule Analysis:** Automatically parse and understand complex HOA CC&Rs.
- **Proactive Alerts:** Receive notifications for potential violations.
- **Compliance Guidance:** Get step-by-step instructions on staying compliant.
- **Fine Mitigation:** Assistance in drafting appeals and communicating with the HOA board.

## Getting Started

### Backend Setup
1. Navigate to the backend directory:
   ```bash
   cd src/backend
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the development server:
   ```bash
   uvicorn main:app --reload
   ```

### Frontend Setup
1. Navigate to the frontend directory:
   ```bash
   cd src/frontend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm start
   ```

## Testing
To run the backend tests:
```bash
export PYTHONPATH=$PYTHONPATH:$(pwd)
pytest src/backend/test_main.py
```

For more details, see the [SPECIFICATION.md](SPECIFICATION.md) file.
