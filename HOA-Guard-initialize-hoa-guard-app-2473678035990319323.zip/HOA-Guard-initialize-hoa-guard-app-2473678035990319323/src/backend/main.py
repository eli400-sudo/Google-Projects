from fastapi import FastAPI

app = FastAPI(title="HOA Guard API")

@app.get("/")
async def root():
    return {"message": "Welcome to HOA Guard API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}
