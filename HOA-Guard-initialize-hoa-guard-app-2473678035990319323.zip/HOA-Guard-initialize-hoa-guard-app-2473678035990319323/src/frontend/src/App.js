import React from 'react';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>HOA Guard Frontend</h1>
        <p>Welcome to the AI-Powered Homeowner Protection & Fine Prevention App.</p>
      </header>
    </div>
  );
}

export default App;
